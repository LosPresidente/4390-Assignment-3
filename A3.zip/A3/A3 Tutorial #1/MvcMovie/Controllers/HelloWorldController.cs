using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace MvcMovie.Controllers
{
    public class HelloWorldController : Controller
    {
        //this part of the code makes it so that /HellowWorld/[something] will render the [something] page from the Views and not from Controller
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Welcome(string name, int numTimes = 1)
        {
            ViewData["Message"] = "This is Ian's test " + name;
            ViewData["NumTimes"] = numTimes;

            return View();
        }
    }
}